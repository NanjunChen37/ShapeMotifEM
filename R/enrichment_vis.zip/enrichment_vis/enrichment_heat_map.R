library(tibble)
library(highcharter)
library(reshape2)
library(pheatmap)

# 
# This enrichment visualization utilize HepG2 ATF3 discovery result as an example
# The .Rdata is attached under the same path
#

TF_name = 'HepG2_ATF3' 
n_features = c(2, 5, 10, 14)

for (n_feature in n_features) {
  
  source_name = paste0("motifLocatorAarry_HepG2_ATF3_AH22689_", n_feature, "_feas_15_100.Rdmpd")
  pdf_name = paste0(TF_name, "_", n_feature, "_features.pdf")
  title = paste("HepG2 ATF3 Shape Motif Enrichment of Top", n_feature, "Features")
  
  n2 = source(source_name)$value
  
  motif_location_array = n2
  
  sort_location = apply(motif_location_array, 2, sort)
  
  all_v0 = all_v1 = all_v2 = c()
  for (i in 1:ncol(sort_location)){
    vector = sort_location[,i]
    frequency_table <- table(vector)
    
    v0 <- rep(i, 115)
    v1 <- as.vector(names(frequency_table))
    v2 <- as.vector(frequency_table)
    
    complete_v1 <- as.character(-14:100)
    complete_v2 <- integer(length(complete_v1))
    complete_v2[match(v1, complete_v1)] <- v2
    
    all_v0 = c(all_v0, v0)
    all_v1 = c(all_v1, complete_v1)
    all_v2 = c(all_v2, complete_v2)
  }
  
  # 创建tibble
  my_tibble <- tibble(
    peak = all_v0,
    location = all_v1,  # 如果你有特定的位置信息，可以替换为实际的值
    frequency = all_v2
  )
  
  data <- acast(my_tibble, peak~location)
  data <- as.matrix(data)
  sorted_index <- order(as.numeric(colnames(data)))
  sorted_data <- data[, sorted_index]
  
  save_pheatmap_pdf <- function(x, filename, width=8, height=8) {
    stopifnot(!missing(x))
    stopifnot(!missing(filename))
    pdf(filename, width=width, height=height)
    grid::grid.newpage()
    grid::grid.draw(x$gtable)
    dev.off()
  }
  
  p = pheatmap(sorted_data,
               cluster_row = FALSE,
               cluster_col = FALSE,
               legend = TRUE,
               border=FALSE,
               cellwidth = 4, 
               cellheight = 4, 
               fontsize = 10,
               fontsize_row = 3,
               fontsize_col = 3,
               annotation_names_row = FALSE,
               color = colorRampPalette(c("white","#E67C30","#DB0400"))(140),
               main = title)
  
  
  save_pheatmap_pdf(p, pdf_name)
  
}
